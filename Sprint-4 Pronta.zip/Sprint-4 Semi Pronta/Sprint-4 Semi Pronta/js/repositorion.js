usuarioLogado = JSON.parse(localStorage.getItem("usuarios"));
usuarioLogado = usuarioLogado[localStorage.getItem("usuarioLogado")];
document.getElementById("nome").value = usuarioLogado.nome;

document.addEventListener('DOMContentLoaded', function () {
  const form = document.getElementById('enviarArquivo');
  const tituloInput = document.getElementById('titulo');
  const nomeInput = document.getElementById("nome");
  const cursoInput = document.getElementById("curso");
  const materiaInput = document.getElementById("materia");
  const professorInput = document.getElementById("professor");
  const mensagemInput = document.getElementById('mensagem');
  const imagemInput = document.getElementById('imagem');
  const arquivosContainer = document.getElementById('arquivos');
  
  

  function salvarArquivo(titulo, nome, curso, materia, professor, mensagem, imagem) {
    const arquivo = {
      titulo: titulo,
      nome: nome,
      curso: curso,
      materia: materia,
      professor: professor,
      mensagem: mensagem,
      imagem: imagem
    };

    let arquivosSalvos = localStorage.getItem('arquivo');
    if (arquivosSalvos) {
      arquivosSalvos = JSON.parse(arquivosSalvos);
    } else {
      arquivosSalvos = [];
    }

    arquivosSalvos.push(arquivo);

    localStorage.setItem('arquivo', JSON.stringify(arquivosSalvos));

  }

  function exibirArquivos() {
    const arquivosSalvos = localStorage.getItem('arquivo');

    if (arquivosSalvos) {
      const arquivos = JSON.parse(arquivosSalvos);
      arquivosContainer.innerHTML = '';

      arquivos.forEach(function (arquivo) {
        const container = document.createElement('div');
        container.className = 'grid-item';

        const titulo = document.createElement('h3');
        titulo.textContent = "TItulo: " + arquivo.titulo;

        const nome = document.createElement('h4');
        nome.textContent = "Criador: " + arquivo.nome;

        const materia = document.createElement('h4');
        materia.textContent = "Materia: " + arquivo.materia;

        const professor = document.createElement('h4');
        professor.textContent = "Professor: " + arquivo.professor;

        const mensagem = document.createElement('p');
        mensagem.textContent = arquivo.mensagem;

        container.appendChild(titulo);
        container.appendChild(nome);
        container.appendChild(materia);
        container.appendChild(professor);
        container.appendChild(mensagem);

        if (arquivo.imagem) {
          const imagem = document.createElement('img');
          imagem.className = 'img-user';
          imagem.src = arquivo.imagem;
          imagem.alt = "Imagem relacionada";
          imagem.style.maxWidth = "100%";
          imagem.style.height = "auto";
          container.appendChild(imagem);
        }

        arquivosContainer.appendChild(container);

      });
    }
  }
  form.addEventListener('submit', function (event) {
    event.preventDefault();

    const titulo = tituloInput.value;
    const nome = nomeInput.value;
    const curso = cursoInput.value;
    const materia = materiaInput.value;
    const professor = professorInput.value;
    const mensagem = mensagemInput.value;
    const imagem = imagemInput.value;


    salvarArquivo(titulo, nome, curso, materia, professor, mensagem, imagem);

    exibirArquivos();

    tituloInput.value = '';
    cursoInput.value = '';
    materiaInput.value = '';
    professorInput.value = '';
    mensagemInput.value = '';
    imagemInput.value = '';
  });

  exibirArquivos();
});
