let imagemUrl = "";
const API_KEY = "x43JOM1iaCwC9A4CSUI8sZCJw2rFV9wT2pI0QOMl5s2NLXZnRsZyB1Cx";

function fetchImagemUrl(categoria) {
  return fetch(`https://api.pexels.com/v1/search?query=${categoria}&per_page=10`, {
    headers: {
      Authorization: API_KEY
    }
  })
    .then(resp => resp.json())
    .then(data => {
      const fotos = data.photos;
      const randomIndex = Math.floor(Math.random() * fotos.length);
      return fotos[randomIndex].src.original;
    });
}

if (localStorage.getItem('usuarios') === null) {
  localStorage.setItem('usuarios', JSON.stringify([]));
}

let usuarios = localStorage.getItem('usuarios');
usuarios = JSON.parse(usuarios);

function validateForm() {
  let password = document.getElementById("password").value;
  let confirmPassword = document.getElementById("confirmPassword").value;
  let age = document.getElementById("age").value;
  let firstname = document.getElementById("firstname").value;
  firstname = firstname.charAt(0).toUpperCase() + firstname.slice(1);
  let usuário = document.getElementById("usuário").value;
  let email = document.getElementById("email").value;
  let Curso = document.getElementById("Curso").value;
  let Período = document.getElementById("Período").value;
  let gender = document.querySelector("input[name='gender']:checked").value;

  if (password !== confirmPassword) {
    alert("As senhas não coincidem!");
    return;
  } else if (!/^(?=.*[A-Za-z])(?=.*\d{4})[A-Za-z\d]{6,}$/.test(password)) {
    alert("A senha deve ter pelo menos 5 dígitos numéricos e uma letra!");
    return;
  }

  if (age < 17 || age > 99) {
    alert("Idade inválida!");
    return;
  }
  
  if (firstname.length < 3) {
    alert("Nome muito curto!");
    return;
  }
  
  if (email.length < 13) {
    alert("Email inválido!");
    return;
  }
  
  const categoria = "pattern"; // Substitua "pattern" pela categoria escolhida pelo usuário

  fetchImagemUrl(categoria)
    .then(url => {
      saveForm(firstname, usuário, email, age, password, Curso, Período, gender, url);
      window.location.href = "index.html";
    })
    .catch(error => {
      console.error("Erro ao obter a imagem:", error);
      alert("Ocorreu um erro ao salvar o formulário. Por favor, tente novamente mais tarde.");
    });
}

function saveForm(firstname, user, email, age, password, course, semester, sex, imagemUrl) {
  let pessoa = {
    imagem: imagemUrl,
    nome: firstname,
    usuario: user,
    email: email,
    idade: age,
    senha: password,
    curso: course,
    periodo: semester,
    genero: sex,
    descricao: "",
    redesSociais: ""
  }

  console.log(usuarios)
  usuarios.push(pessoa)
  localStorage.setItem('usuarios', JSON.stringify(usuarios))
}
