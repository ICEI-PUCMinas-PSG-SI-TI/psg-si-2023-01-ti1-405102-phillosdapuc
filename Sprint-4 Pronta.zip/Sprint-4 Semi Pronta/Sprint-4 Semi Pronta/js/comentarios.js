usuarioLogado = JSON.parse(localStorage.getItem("usuarios"));
usuarioLogado = usuarioLogado[localStorage.getItem("usuarioLogado")];
document.getElementById("nome").value = usuarioLogado.nome;

function postarComentario() {
    var nome = document.getElementById("nome").value;
    var texto = document.getElementById("textarea").value;
    var dataHora = new Date().toLocaleString();

    if (texto.trim() === "") {
        return;
    }
    var comentario = {
        nome: nome,
        texto: texto,
        dataHora: dataHora
    };
    var comentarios = JSON.parse(localStorage.getItem("comentarios")) || [];

    comentarios.push(comentario);

    localStorage.setItem("comentarios", JSON.stringify(comentarios));

    document.getElementById("textarea").value = "";
}

document.getElementById("postarComentario").addEventListener("click", postarComentario);
