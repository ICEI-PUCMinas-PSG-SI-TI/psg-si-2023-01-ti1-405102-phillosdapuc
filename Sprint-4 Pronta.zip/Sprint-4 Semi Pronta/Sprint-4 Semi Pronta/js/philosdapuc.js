document.addEventListener("DOMContentLoaded", function () {
    pegarPerguntas();
});
  
function pegarPerguntas() {
    let comentarios = JSON.parse(localStorage.getItem("comentarios"));
    let container = document.getElementById('paginax');
  
    if (comentarios && comentarios.length > 0) {
      for (let i = 0; i < comentarios.length; i++) { 
        container.innerHTML += 
        `
        <div class="pergunta">
            <a href="forum2.html"><h3>${comentarios[i].nome}</h3><p>${comentarios[i].dataHora}</p></a>
        </div>
        `;
    }}
}
