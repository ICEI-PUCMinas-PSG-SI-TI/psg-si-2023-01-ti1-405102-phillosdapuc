function preencherImagemUsuario() {
    let imagens = document.querySelectorAll('.imagemUrl')


    let usuarioLogado = localStorage.getItem('usuarioLogado')

    let usuarios = JSON.parse(localStorage.getItem('usuarios'))
    for (let i = 0; i < imagens.length; i++) {
        imagens[i].src = usuarios[usuarioLogado].imagem
    }
}
preencherImagemUsuario()