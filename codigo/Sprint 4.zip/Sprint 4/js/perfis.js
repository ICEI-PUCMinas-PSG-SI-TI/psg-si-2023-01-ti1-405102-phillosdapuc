function pegarUsuarios(){
    let usuarios = JSON.parse(localStorage.getItem("usuarios"))
    let container = document.querySelector(".cards")

    for(let i = 0; i < usuarios.length; i++){
        if(usuarios[i].imagem == ""){
            usuarios[i].imagem = "./Imagens/person-circle.svg"
        }

        container.innerHTML +=
        `
        <div class="card" onclick="window.location.href='profile.html?idUsuario=${i}'">
            <img src="${usuarios[i].imagem}" alt="" class="imagemUsuario">
            <h3 class="nomeUsuario">${usuarios[i].nome}</h3>
            <p class="descricaoUsuario">${usuarios[i].descricao}</p>
            <p>${usuarios[i].redesSociais}</p>
        </div>
        `
    }
}

pegarUsuarios()