function editarPerfil() {
    let button1 = document.querySelectorAll(".botao")[0]

    let input1 = document.querySelectorAll("main input")[0]
    let input2 = document.querySelectorAll("main input")[1]
    let input3 = document.querySelectorAll("main input")[2]

    input1.removeAttribute("disabled")
    input2.removeAttribute("disabled")
    input3.removeAttribute("disabled")


    let textarea1 = document.querySelectorAll("textarea")[0]
    let textarea2 = document.querySelectorAll("textarea")[1]

    button1.style.display = "block"


    textarea1.removeAttribute("disabled")
    textarea2.removeAttribute("disabled")
}

function atualizarPerfil() {
    let usuarios = localStorage.getItem("usuarios")
    let usuarioLogado = localStorage.getItem("usuarioLogado")

    usuarios = JSON.parse(usuarios)
    usuarioLogado = JSON.parse(usuarioLogado)

    let button1 = document.querySelectorAll(".botao")[0]

    let input1 = document.querySelectorAll("main input")[0]
    let input2 = document.querySelectorAll("main input")[1]
    let input3 = document.querySelectorAll("main input")[2]

    let textarea1 = document.querySelectorAll("textarea")[0]
    let textarea2 = document.querySelectorAll("textarea")[1]

    usuarios[usuarioLogado].idade = input1.value
    usuarios[usuarioLogado].curso = input2.value
    usuarios[usuarioLogado].periodo = input3.value

    usuarios[usuarioLogado].descricao = textarea1.value
    usuarios[usuarioLogado].redesSociais = textarea2.value

    textarea1.setAttribute("disabled", "")
    textarea2.setAttribute("disabled", "")
    button1.style.display = "none"

    input1.setAttribute("disabled", "")
    input2.setAttribute("disabled", "")
    input3.setAttribute("disabled", "")

    usuarios = JSON.stringify(usuarios)
    localStorage.setItem("usuarios", usuarios)

}

function preencherCampos() {
    let usuarios = localStorage.getItem("usuarios");
    let usuarioLogado = localStorage.getItem("usuarioLogado");

    usuarios = JSON.parse(usuarios);
    usuarioLogado = JSON.parse(usuarioLogado);

    let textarea1 = document.querySelectorAll("textarea")[0];
    let textarea2 = document.querySelectorAll("textarea")[1];

    document.getElementById("nomePerfil").innerHTML = usuarios[usuarioLogado].nome
    document.getElementById("idadePerfil").value = usuarios[usuarioLogado].idade
    document.getElementById("cursoPerfil").value = usuarios[usuarioLogado].curso
    document.getElementById("periodoPerfil").value = usuarios[usuarioLogado].periodo


    textarea1.value = usuarios[usuarioLogado].descricao;
    textarea2.value = usuarios[usuarioLogado].redesSociais;
}

preencherCampos();

