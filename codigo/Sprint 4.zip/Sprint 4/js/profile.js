function preencherCampos() {
  let usuarios = JSON.parse(localStorage.getItem("usuarios"));
  let idUsuario = new URLSearchParams(window.location.search)
  idUsuario = idUsuario.get("idUsuario")

  usuarios = usuarios[idUsuario]

  let textarea1 = document.querySelectorAll("textarea")[0];
  let textarea2 = document.querySelectorAll("textarea")[1];

  document.getElementById("nomePerfil").innerHTML = usuarios.nome
  document.getElementById("idadePerfil").value = usuarios.idade
  document.getElementById("cursoPerfil").value = usuarios.curso
  document.getElementById("periodoPerfil").value = usuarios.periodo
  if(usuarios.imagem != ""){
    document.querySelector(".imagemUrl").src = usuarios.imagem
  }


  textarea1.value = usuarios.descricao;
  textarea2.value = usuarios.redesSociais;
}

preencherCampos();