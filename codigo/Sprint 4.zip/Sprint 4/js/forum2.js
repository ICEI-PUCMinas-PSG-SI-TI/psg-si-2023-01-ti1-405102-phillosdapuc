document.addEventListener("DOMContentLoaded", function () {
  pegarPerguntas();
});

function pegarPerguntas() {
  let comentarios = JSON.parse(localStorage.getItem("comentarios"));
  let container = document.getElementById('cards');

  if (comentarios && comentarios.length > 0) {
    for (let i = 0; i < comentarios.length; i++) { 
      container.innerHTML += 
      `
      <div class="forum2">
        <p>${comentarios[i].nome}</p>
        <h2 class="Pergunta">${comentarios[i].texto}</h2>
        <div class="replyButton">
          <button class="resp" type="button">Resposta</button>
        </div>
      </div>
      `;
    }
  }

  const respBtn = document.querySelectorAll(".replyButton button");

  for (let i = 0; i < respBtn.length; i++) {
    respBtn[i].addEventListener("click", function () {
      const duvida = this.parentNode.parentNode.querySelector(".Pergunta").textContent.trim();
      showPopup(duvida);
    });
  }
}

const modalOverlay = document.getElementById("modalOverlay");

function showPopup(duvida) {
  if (localStorage.getItem (duvida) == null) {
    localStorage.setItem (duvida, "[]");
  }

  let respostas = localStorage.getItem(duvida);
  respostas = JSON.parse(respostas);

  const modal = document.createElement("div");
  modal.classList.add("modal");

  const modalTitle = document.createElement("h2");
  modalTitle.classList.add("modal-title");
  modalTitle.textContent = duvida;
  modal.appendChild(modalTitle);

  const modalContent = document.createElement("div");
  modalContent.classList.add("modal-content");
  modal.appendChild(modalContent);

  const iconeX = document.createElement("img");
  iconeX.classList.add("iconeFechar");
  iconeX.src = "./Imagens/x-circle.svg";
  modalContent.appendChild(iconeX);

  for (let i = 0; i < respostas.length; i++) {
    let respostaHtmtl = document.createElement("p");
    respostaHtmtl.classList.add("respostaPergunta");
    respostaHtmtl.textContent = respostas[i];
    modalContent.appendChild(respostaHtmtl);
  }

  const respostaTextArea = document.createElement("textarea");
  respostaTextArea.classList.add("modal-textarea");
  respostaTextArea.placeholder = "Digite sua resposta";
  modalContent.appendChild(respostaTextArea);

  const saveButton = document.createElement("button");
  saveButton.classList.add("modal-button");
  saveButton.textContent = "Enviar";
  modalContent.appendChild(saveButton);

  saveButton.addEventListener("click", salvarResposta);

  iconeX.addEventListener("click", fecharPopup);

  document.body.appendChild(modal);

  modalOverlay.style.display = "block";
  modal.style.display = "block";
}


function fecharPopup() {

  const modal = document.querySelector(".modal");
  document.body.removeChild(modal);

  modalOverlay.style.display = "none";
}

function salvarResposta() {
  const modal = document.querySelector(".modal");
  const respostaTextArea = modal.querySelector(".modal-textarea");
  const resposta = respostaTextArea.value; 
  const pergunta = modal.querySelector(".modal-title").innerHTML;

  if (respostaTextArea.value == "") {
    fecharPopup();
    return;
  }
  
  if (localStorage.getItem (pergunta) == null) {
    localStorage.setItem (pergunta, JSON.stringify([]));
  }

  let respostasAnteriores = localStorage.getItem(pergunta);
  respostasAnteriores = JSON.parse(respostasAnteriores);

  respostasAnteriores.push(resposta);
  let respostas = respostasAnteriores;
  localStorage.setItem(pergunta, JSON.stringify(respostas));

  fecharPopup();
}


