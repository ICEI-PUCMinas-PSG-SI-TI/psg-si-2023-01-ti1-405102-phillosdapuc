let id = 1

if(localStorage.getItem("paginas") == null){
    localStorage.setItem("paginas", "[]")
}

let paginas = localStorage.getItem ("paginas")
paginas = JSON.parse(paginas)

function criar_pagina(){
    let inputs_array = document.querySelectorAll("main input")
    let text_area = document.querySelector("#areadetexto")
    //console.log(inputs_array)

    let pagina = {
        titulo_da_pagina : inputs_array[0].value,
        curso_referente : inputs_array[1].value,
        materia_referente : inputs_array[2].value,
        link_referencia : inputs_array[3].value,
        professor : inputs_array[4].value,
        corpo_de_texto : text_area.value
    }

    console.log(inputs_array[0].value)

    paginas.push(pagina)
    localStorage.setItem("paginas", JSON.stringify(paginas))
    localStorage.setItem("paginaSelecionada", paginas.length - 1)
    window.location.href = "Struct.html"
    
    id +=1
}
