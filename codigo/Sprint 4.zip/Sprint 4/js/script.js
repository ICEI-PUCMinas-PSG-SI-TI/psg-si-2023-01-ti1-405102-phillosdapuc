let usuarios = localStorage.getItem('usuarios')
usuarios = JSON.parse(usuarios)

function logar() {
    let nomedigitado = document.getElementById("name").value
    let senhadigitada = document.getElementById("password").value
    console.log(nomedigitado)
    for (let i = 0; i < usuarios.length; i++) {
        if (usuarios[i].usuario == nomedigitado && usuarios[i].senha == senhadigitada) {
            localStorage.setItem('usuarioLogado', i)
            window.location.href = 'Philosdapuc.html' 
        }
    }
}
